public class PrintCharacters {
    public static void main(String[] args) {
        char character = 'a';

        for(char i = character; i <= 'z'; i++) {
            System.out.print(" " + character++);
        }
    }
}
