import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GhettoNumeralSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num = sc.nextInt();
        List<String> ghettoNumbersList = new ArrayList<>();

        while (num > 0){
            int lastNum = num % 10;
            String ghettoNum = ghettoNumDatabase(lastNum);
            ghettoNumbersList.add(ghettoNum);
            num = num / 10;
        }

        for (int i = ghettoNumbersList.size() - 1; i >= 1 ; i--) {
            System.out.print(ghettoNumbersList.get(i));
        }
        System.out.println();

    }

    private static String ghettoNumDatabase(int num){
        String[] ghettoNumeralSystem = new String[]{"Gee", "Bro", "Zuz", "Ma", "Duh", "Yo", "Dis", "Hood", "Jam", "Mack"};
        String ghettoNum = ghettoNumeralSystem[num];
        return ghettoNum;
    }
}
