import java.io.StringWriter;

public class AssignVariables {
    public static void main(String[] args){
        byte byteNum = 127;
        short shortNum = 32767;
        int integerNum = 2000000000;
        long longNum =  919827112351L;
        String str = "Palo Alto, CA";
        char oneChar = 'c';
        boolean isTrue = false;
        float floatNum = 0.5f;
        double doubleNum = 0.1234567891011;

        //short try = 32768;
        //System.out.println(try);
    }
}
