import java.util.Scanner;

public class GetAverage {
    private GetAverage() {
    }

    public static void main(String[] args){
        System.out.println("Enter 3 numbers, but remember ONLY 3: ");
        Scanner sc = new Scanner(System.in);

        double num1, num2, num3;
        double avrg;

        num1 = sc.nextDouble();
        num2 = sc.nextDouble();
        num3 = sc.nextDouble();

        avrg = getAverage(num1, num2, num3);
        System.out.println(String.format("%.2f", avrg));
    }

    public static double getAverage(double a, double b, double c){
        return (a + b + c) / 3;
    }
        }
